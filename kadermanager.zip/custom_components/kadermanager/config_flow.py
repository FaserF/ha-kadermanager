import logging
from typing import Any
import voluptuous as vol

from homeassistant import config_entries
from homeassistant.core import callback
from homeassistant.config_entries import ConfigFlowResult

from .const import (
    CONF_EVENT_LIMIT,
    CONF_FETCH_COMMENTS,
    CONF_FETCH_PLAYER_INFO,
    CONF_FORCE_UPDATE,
    CONF_DYNAMIC_INTERVAL,
    CONF_PASSWORD,
    CONF_TEAM_NAME,
    CONF_UPDATE_INTERVAL,
    CONF_USERNAME,
    DOMAIN,
)
from .coordinator import validate_input, CannotConnect, InvalidAuth

_LOGGER = logging.getLogger(__name__)


class OptionsFlowHandler(config_entries.OptionsFlow):
    def __init__(self, config_entry: config_entries.ConfigEntry) -> None:
        """Initialize options flow."""
        self._config_entry = config_entry

    async def async_step_init(
        self, user_input: dict[str, Any] | None = None
    ) -> ConfigFlowResult:
        """Manage the options."""

        def __get_option(key: str, default: Any) -> Any:
            return self._config_entry.options.get(
                key, self._config_entry.data.get(key, default)
            )

        if user_input is not None:
            if user_input.get(CONF_FORCE_UPDATE):
                # Trigger a force refresh on the existing coordinator
                if (
                    DOMAIN in self.hass.data
                    and self._config_entry.entry_id in self.hass.data[DOMAIN]
                ):
                    coordinator = self.hass.data[DOMAIN][self._config_entry.entry_id]
                    coordinator._force_update = True
                    self.hass.async_create_task(coordinator.async_request_refresh())

                # Remove it so it doesn't get saved into options permanently
                user_input.pop(CONF_FORCE_UPDATE)

            return self.async_create_entry(
                title=user_input.get(CONF_TEAM_NAME, ""), data=user_input
            )

        return self.async_show_form(
            step_id="init",
            data_schema=vol.Schema(
                {
                    vol.Required(
                        CONF_TEAM_NAME, default=__get_option(CONF_TEAM_NAME, "")
                    ): str,
                    vol.Optional(
                        CONF_USERNAME, default=__get_option(CONF_USERNAME, "")
                    ): str,
                    vol.Optional(
                        CONF_PASSWORD, default=__get_option(CONF_PASSWORD, "")
                    ): str,
                    vol.Required(
                        CONF_UPDATE_INTERVAL,
                        default=__get_option(CONF_UPDATE_INTERVAL, 60),
                    ): vol.All(vol.Coerce(int), vol.Range(min=60, max=1440)),
                    vol.Required(
                        CONF_EVENT_LIMIT, default=__get_option(CONF_EVENT_LIMIT, 3)
                    ): vol.All(vol.Coerce(int), vol.Range(min=1, max=10)),
                    vol.Required(
                        CONF_FETCH_PLAYER_INFO,
                        default=__get_option(CONF_FETCH_PLAYER_INFO, True),
                    ): bool,
                    vol.Required(
                        CONF_FETCH_COMMENTS,
                        default=__get_option(CONF_FETCH_COMMENTS, True),
                    ): bool,
                    vol.Optional(
                        CONF_FORCE_UPDATE,
                        default=False,
                    ): bool,
                    vol.Optional(
                        CONF_DYNAMIC_INTERVAL,
                        default=__get_option(CONF_DYNAMIC_INTERVAL, False),
                    ): bool,
                },
            ),
        )


class ConfigFlow(config_entries.ConfigFlow, domain=DOMAIN):  # type: ignore
    """Handle a config flow"""

    VERSION = 2
    CONNECTION_CLASS = config_entries.CONN_CLASS_CLOUD_POLL

    async def async_step_user(self, user_input=None):
        """Handle the initial step."""
        errors = {}

        if user_input is not None:
            await self.async_set_unique_id(user_input[CONF_TEAM_NAME])
            self._abort_if_unique_id_configured()

            try:
                await validate_input(self.hass, user_input)
                return self.async_create_entry(
                    title=user_input[CONF_TEAM_NAME], data=user_input
                )

            except CannotConnect:
                errors["base"] = "cannot_connect"
            except InvalidAuth:
                errors["base"] = "invalid_auth"
            except Exception:  # pylint: disable=broad-except
                _LOGGER.exception("Unexpected exception")
                errors["base"] = "unknown"

        data_schema = vol.Schema(
            {
                vol.Required(CONF_TEAM_NAME): str,
                vol.Optional(CONF_USERNAME): str,
                vol.Optional(CONF_PASSWORD): str,
                vol.Required(CONF_UPDATE_INTERVAL, default=60): vol.All(
                    vol.Coerce(int), vol.Range(min=60, max=1440)
                ),
                vol.Required(CONF_EVENT_LIMIT, default=3): vol.All(
                    vol.Coerce(int), vol.Range(min=1, max=10)
                ),
                vol.Required(CONF_FETCH_PLAYER_INFO, default=True): bool,
                vol.Required(CONF_FETCH_COMMENTS, default=True): bool,
                vol.Optional(CONF_DYNAMIC_INTERVAL, default=False): bool,
            },
        )

        return self.async_show_form(
            step_id="user",
            data_schema=data_schema,
            errors=errors,
        )

    @staticmethod
    @callback
    def async_get_options_flow(
        config_entry: config_entries.ConfigEntry,
    ) -> config_entries.OptionsFlow:
        """Create the options flow."""
        return OptionsFlowHandler(config_entry)
