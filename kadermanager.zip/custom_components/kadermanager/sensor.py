import logging
from typing import Optional, cast

from homeassistant import config_entries
from homeassistant.components.sensor import SensorEntity
from homeassistant.core import HomeAssistant
from homeassistant.helpers.entity_platform import AddEntitiesCallback
from homeassistant.helpers.update_coordinator import CoordinatorEntity

from .const import DOMAIN, CONF_TEAM_NAME
from .coordinator import KadermanagerDataUpdateCoordinator

_LOGGER = logging.getLogger(__name__)


async def async_setup_entry(
    hass: HomeAssistant,
    entry: config_entries.ConfigEntry,
    async_add_entities: AddEntitiesCallback,
):
    """Setup sensors from a config entry created in the integrations UI."""
    coordinator: KadermanagerDataUpdateCoordinator = hass.data[DOMAIN][entry.entry_id]
    async_add_entities([KadermanagerSensor(coordinator, entry)])


class KadermanagerSensor(CoordinatorEntity, SensorEntity):
    """Implementation of a Kadermanager sensor."""

    def __init__(
        self,
        coordinator: KadermanagerDataUpdateCoordinator,
        entry: config_entries.ConfigEntry,
    ):
        super().__init__(coordinator)
        self.teamname = entry.data[CONF_TEAM_NAME]
        self._name = f"Kadermanager {self.teamname}"
        self._entry_id = entry.entry_id

    @property
    def name(self):
        return self._name

    @property
    def unique_id(self) -> str:
        return f"{self._entry_id}_sensor"

    @property
    def icon(self):
        return "mdi:volleyball"

    @property
    def native_value(self) -> Optional[str]:
        coordinator: KadermanagerDataUpdateCoordinator = cast(
            KadermanagerDataUpdateCoordinator, self.coordinator
        )
        if not coordinator.data:
            if coordinator.last_success:
                return "No events found"
            return "Initializing..."

        events = coordinator.data.get("events")
        if not events:
            return "No events found"

        return events[0]["original_date"]

    @property
    def extra_state_attributes(self):
        coordinator: KadermanagerDataUpdateCoordinator = cast(
            KadermanagerDataUpdateCoordinator, self.coordinator
        )
        data = coordinator.data or {}
        attrs = {
            "events": data.get("events", []),
            "last_updated": (
                coordinator.last_success.isoformat()
                if coordinator.last_success
                else None
            ),
        }
        if "general_comments" in data:
            attrs["comments"] = data["general_comments"]
        elif "comments" not in attrs:
            attrs["comments"] = []

        return attrs

    @property
    def available(self) -> bool:
        return self.coordinator.last_update_success

    @property
    def attribution(self):
        from .const import ATTRIBUTION

        return ATTRIBUTION

    @property
    def device_info(self):
        """Return device information about this entity."""
        return {
            "identifiers": {(DOMAIN, self.teamname)},
            "name": f"Kadermanager {self.teamname}",
            "manufacturer": "Kadermanager",
            "model": "Team Schedule",
            "configuration_url": f"https://{self.teamname.lower()}.kadermanager.de",
        }
